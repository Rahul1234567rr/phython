#Sum of n natural numbers by using loops

n = int(input('Enter n:'))
m = int(input('Enter m:')
s = 0
print('s', '+  i')
while m<=n:
    print(s, '+', m, '=', s+i)
    s += i
    m += 1
print(s)
