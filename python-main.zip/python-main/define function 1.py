def gr():
    print('Gangadhar \n \t Neelam')
gr()


