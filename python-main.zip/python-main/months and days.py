#month and number of days it has
m = int(input("Enter a month:"))
if m ==1:
    print(m,"st month has 31 days")
elif m==2:
    print(m,"nd month has 28 days")
elif m==3:
    print(m,"rd month has 31 days")
elif m==4:
    print(m,"th month has 30 days")
elif m==5:
    print(m,"th month has 31 days")
elif m==6:
    print(m,"th month has 30 days")
elif m==7:
    print(m,"th month has 31 days")
elif m==8:
    print(m,"th month has 31 days")
elif m==9:
    print(m,"th month has 30 days")
elif m==10:
    print(m,"th month has 31 days")
elif m==11:
    print(m,"th month has 30 days")
elif m==12:
    print(m,"th month has 31 days")
else:
    print("There is only 12 months")
