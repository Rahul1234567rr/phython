"Simple inerest"
p = int(input("Enter the value of Principal="))
t = int(input("Enter the time="))
r = float(input("Enter the rate of inerest ="))
S_I = p*t*r//100
print("Simple Interest=", S_I)
