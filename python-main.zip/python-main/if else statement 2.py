n1 = int(input("Enter the first number:"))
n2 = int(input("Enter the second number:"))
if n1<n2:
    print(n1, "is less than", n2)
elif n1>n2:
    print(n1, "is greater than", n2)
else:
    print(n1, "is equal to", n2)
