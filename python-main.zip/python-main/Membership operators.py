#MEMBERSHIP OPEARATORS

# in 
# not in
#Example:
l = input('Enter an alphabet:')
vowels = 'aeiouAEIOU'
if l in vowels
:
    print(l, 'is an vowel')
else:
    print(l, 'is a consonant')
