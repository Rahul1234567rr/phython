def num(n):
    if n%5==0:
        return true
    return false
r = num(56)
print(r)
