#Function with retutrn values
#A function can return values if necessary
def add(a, b):
    c = (a+b)
    return c
print(add(20, 30))
