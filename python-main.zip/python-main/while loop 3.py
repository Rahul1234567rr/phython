n = int(input('n'))
m = int(input('m'))
i = 0
while i<m:
    print(i, 'is less than', m)
    i += 1
else :
    print(i, 'is not less than', m)
