# To check if number is positive ot negative

n = int(input("Enter an Integer:"))    
if n>0:
    print(n, "It is a positive integer")
elif n<0:
     print(n, "It is a Negative integer")
else:
    print(n, "It is a zero")
