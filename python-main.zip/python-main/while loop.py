#While loop
a = 1
while a<8:
    print(a)
    a +=1
