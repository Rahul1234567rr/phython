n =int(input('Enter a number:'))
for i in range(1, 13):
    print(n, 'x', i, '=', n*i)
    
