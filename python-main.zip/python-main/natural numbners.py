n = 100
s = n*(n+1)/2
print("The sum of first", n, "natural numbers =", s)

n = 50
s = n*(n+1)*(2*n+1)/6
print("\nThe sum of the sqaures of first", n, "natural numbers=", s)

n = 25
s = n**2*(n+1)**2/4
print("\nThe sum of the cubes of first", n, "natural numbers=", s)


n = 18
s = n*(n+1)
print("\nThe sum of first", n, "even natural numbers=", s)

n = 7
s = n**2
print("\nThe sum of first", n, "odd natural numbers=", s)

n = 25
SE = n*(n+1)
SO = n**2
print("\nThe sum of first", n, "even natural numbers=", SE)
print("The sum of first", n, "odd natural numbers=", SO)
print("The difference SE and SO =", SE-SO)
