def gr(name):
    print('Hello' , name, '\nWork hard until you get success\n\"Make your parents proud\"')
gr('ram')
