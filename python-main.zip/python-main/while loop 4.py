#Sum of n natural numbers from n to m
n = int(input('n:'))
m = int(input('m:'))
s = 0
if n<m:
    while n>=m:
       else:
         s += n
         n -= 1
print(s)
