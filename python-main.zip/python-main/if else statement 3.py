# Printing word for digit
n = int(input("Enter a digit:"))
if n==0:
    print("Zero")
    n==1
elif n==1:
    print("One")
elif n==2:
    print("Two")
elif n==3:
    print("Three")
elif n==4:
    print("Four")
elif n==5:
    print("Five")
elif n==6:
    print("Six")
elif n==7:
    print("Seven")
elif n==8:
    print("Eight")
elif n==9:
    print("Nine")
else:
    print("It is not a digit")
