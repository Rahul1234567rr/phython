for i in range(7, 18, 2):
    print(i, end =' ')
