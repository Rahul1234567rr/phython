def gr(name, a, b):
    print('Hello', name,'Welcome to the world\n', a*b)
gr('')

