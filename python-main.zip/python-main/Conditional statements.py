#Conditional statement")

Age = int(input("Enter your age:"))
if Age>18:
    print("You can vote")
else:
    print("You cannot vote")
