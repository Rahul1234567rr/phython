n = float(input("Enter the value of n:"))
s = n*(n+1)//2
r = n**2
print("The sum of first", n, "even natural numbers", s)
print("The sum of first", n, "odd natural numbers", r)
print("The difference of s and r =", s-r)
