#Default arguments in functions:

def loc(city, country = "India"):
    print(city, 'is in', country)
loc ('Mumbai')

#if two arguments given, default argument doesn't works
