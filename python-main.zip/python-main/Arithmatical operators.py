*/ARITHMETICAL OPERATORS :

+ --> Addition

- --> Subtraction

* --> Multiplication

/ --> Division

// --> Floor division

% --> Modulo division

** --> Exponentiation*/

a = int(input("Enter the value of a:"))
b = int(input("Enter the value of b:"))
A = a+b
S = a-b
M = a*b
D = a/b
FD = a//b
MD = a%b
E = a**b
T = A+S+M+D+FD+MD+E
print("Sum of", a, "and", b, "is", A)
print("Difference of", a, "and", b, "is", S)
print("Productof", a, "and", b, "is",  M)
print("Quotient when", a, "divided by", b, "is", D)
print("Floor quotient when", a, "divided by", b, "is", FD)
print("Remainder when", a, "divided by", b, "is", MD)
print("Value of", a, "power to the", b, "is", E)
print("Total =", T)
