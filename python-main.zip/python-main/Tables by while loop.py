a = int(input("Enter a:"))
b = int(input("Enter b:"))
while a<=b:
    i = 18
    while i<=18:
        print(b, "x", i, "=", b*i)
        i -= 1
        if i == 0:
            break
    print()
    b -= 1
