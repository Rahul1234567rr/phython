a = int(input("Enter a:"))
b = int(input("Enter b:"))
while a<=b:
    i = 1 #from 1 --> 18
    while i<=18:
        print(a, "x", i, "=", a*i)
        i += 1 
    print()
    a += 1 #from a -->b
