a = input("Enter an alphabet:")
if a=='a' or a=='A' or a=='e' or a=='E' or a=='i' or a=='I' or a=='o' or a=='O' or a=='u' or a=='U':
    print(a, "is an vowel")
else:
    print(a, "is a consonant")
