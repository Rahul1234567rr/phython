#While loop

i = 7
while i>=1:
    print('Gangaram', i)
    i=i-1
