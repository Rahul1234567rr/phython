s = 'Gangadhara gannibabu'
for i in s:
    print(i, end='')
